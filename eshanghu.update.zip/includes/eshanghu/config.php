<?php
/*易商户支付配置*/
return [
    'app_key' => 'vfLDXwu4uwc5962ObdmzKvUdMDA3NVNO', //用户中心开发设置中获取
    'app_secret' => 'Qu161gBavPMJGCmB53w2gkH1eG7sIhjh', //用户中心开发设置中获取
    'sub_mch_id' => '1534120101',  //https://1shanghu.com/user/wechat/certification 获取
    'notify' => 'http://'.$conf['local_domain'].'/eshanghu_notify.php', //回调地址
];
?>